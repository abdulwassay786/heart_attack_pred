from django.apps import AppConfig


class PredDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pred_data'
